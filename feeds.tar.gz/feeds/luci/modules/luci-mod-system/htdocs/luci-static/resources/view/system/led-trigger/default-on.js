'use strict';
'require baseclass';

return baseclass.extend({
	trigger: _('Always on (kernel: default-on)'),
	kernel: true,
	addFormOptions: function(s) {}
});
