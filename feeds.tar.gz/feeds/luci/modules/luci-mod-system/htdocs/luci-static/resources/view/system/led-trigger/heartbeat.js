'use strict';
'require baseclass';

return baseclass.extend({
	trigger: _('Heartbeat interval (kernel: heartbeat)'),
	kernel: true,
	addFormOptions: function(s) {}
});
