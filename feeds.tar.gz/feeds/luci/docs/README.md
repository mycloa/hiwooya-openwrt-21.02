# LuCI Documentation

## API Reference

 - [Client side JavaScript APIs](jsapi/index.html)
 - [Server side Lua APIs](api/index.html)
